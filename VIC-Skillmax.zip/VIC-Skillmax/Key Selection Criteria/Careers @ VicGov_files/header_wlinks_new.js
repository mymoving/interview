document.open();
document.write(
'<!--START HEADER-->',

'<table width="100%"  border="0" cellspacing="0" cellpadding="0" class="header_back">',
'  <tr>',
'    <td background="/graphics/header_back.gif"><img src="/graphics/logo.gif" alt="Careers with Victorian Government header"/></td>',
'    <td background="/graphics/header_stars.gif" width="20%">&nbsp;</td>',
'  </tr>',
'</table>',

'<table width="100%" border="0" cellspacing="0" cellpadding="0">',
'  <tr>',
'    <td height="33" align="center" valign="top" bgcolor="#003580">&nbsp;</td>',
'  </tr>',
'</table>',
'<table width="100%"  border="0" cellspacing="0" cellpadding="0" class="primary_bott">',
'  <tr>',
'    <td height="16"><img src="/graphics/primary_bottom.gif" width="5" height="16"/></td>',
'  </tr>',
'</table>',
'<table width="100%"  border="0" cellspacing="0" cellpadding="0">',
'  <tr>',
'    <td height="20">&nbsp;</td>',
'  </tr>',
'</table>',
'<div id="secondary_top">&nbsp;</div>',

'<!--END HEADER-->'
);
